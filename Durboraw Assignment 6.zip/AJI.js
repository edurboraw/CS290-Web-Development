/**
 * Created by Eric Durboraw on 5/13/2017.
 */

document.addEventListener('DOMContentLoaded', bindButtons);

function bindButtons(){
    document.getElementById('placeSubmit').addEventListener('click', function(event)
    {
        var req = new XMLHttpRequest();
        var url = "http://api.openweathermap.org/data/2.5/weather?";
        var appId = "&appid=fa7d80c48643dfadde2cced1b1be6ca1";
        var FInput = document.getElementById("place").value;

        if (document.getElementById('place1').checked) {
            formInput = "q=" + FInput;
        }
        else if(document.getElementById('place2').checked){
            formInput = "zip=" + FInput;
        }
        console.log(formInput);
        var finalUrl = url + formInput + appId + '&units=imperial';
        req.open("GET", finalUrl, true);
        req.addEventListener('load', function() {
            if (req.status >= 200 && req.status < 400) {
                var Response = JSON.parse(req.responseText);
                console.log(Response);
                document.getElementById('name').textContent = Response.name;
                document.getElementById('main').textContent = Response.main.humidity;
                document.getElementById('temp').textContent = Response.main.temp;
                document.getElementById('wind').textContent = Response.wind.speed;
                document.getElementById('temp_min').textContent = Response.main.temp_min;
                document.getElementById('temp_max').textContent = Response.main.temp_max;
            } else {
                console.log("Error");
            }
        });
        req.send();
        event.preventDefault();
    });

    document.getElementById('contentSubmit').addEventListener('click', function(event)
    {
        var req = new XMLHttpRequest();
        var url = "http://httpbin.org/post";
        var content = document.getElementById("content").value;
        req.open("POST", "http://httpbin.org/post", true);
        req.setRequestHeader('Content-Type', 'application/json');
        req.send(JSON.stringify(content));
        req.addEventListener("load", function(){
        if(req.status >= 200 && req.status < 400){
            var response = JSON.parse(req.responseText);
            document.getElementById("returnIn").textContent = response.data;
            document.getElementById("returnFrom").textContent = JSON.stringify(response);
        }
        else{
            console.log("Fail");
        }
        });
        event.preventDefault();
    });

}