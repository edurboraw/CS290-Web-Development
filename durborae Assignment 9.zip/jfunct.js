/**
 * Created by Eric on 6/9/2017.
 */
function showEdit(idVar) {
    var el;
    el = document.getElementById(idVar);
    el.style.display = el.style.display === "none" ? "block" : "none";
}


function deleteRow(){
    var id = this.id;
    var req = new XMLHttpRequest();
    var link = "http://flip3.engr.oregonstate.edu:3118/delete?id=";
    req.open("GET", link + id, true);
    req.addEventListener("load", function(){
        if(req.status >= 200 && req.status < 400){
            var node = document.getElementById(id);
            if(node.parentNode){
                node.parentNode.removeChild(node);
            }
        }
        else{
            console.log("Error in network request");
        }
    });
    req.send(JSON.stringify(req.responseText));
    event.preventDefault();
}

document.getElementById("delete-button").addEventListener("click", deleteRow);


function deleteRow(tableID,currentRow) {
    try {
        var table = document.getElementById(tableID);
        var rowCount = table.rows.length;
        for (var i = 0; i < rowCount; i++) {
            var row = table.rows[i];


            if (row==currentRow.parentNode.parentNode) {
                if (rowCount <= 1) {
                    alert("Cannot delete all the rows.");
                    break;
                }
                table.deleteRow(i);
                rowCount--;
                i--;
            }
        }
    } catch (e) {
        alert(e);
    }
}