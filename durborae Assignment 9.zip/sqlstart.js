/**
 * Created by Eric on 6/4/2017.
 */
var mysql = require('mysql');
var pool = mysql.createPool({
    connectionLimit : 10,
    host            : 'classmysql.engr.oregonstate.edu',
    user            : 'cs290_durborae',
    password        : '3118',
    database        : 'cs290_durborae'
});

module.exports.pool = pool;
