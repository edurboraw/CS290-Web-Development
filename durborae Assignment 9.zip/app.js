/*var express = require('express');
var mysql = require('./routes/sqlstart.js');
var bodyParser = require('body-parser');
var app = express();
var handlebars = require('express-handlebars').create({defaultLayout: 'main'});

app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');
app.set('port', 3318);
app.set('view engine', 'handlebars');
app.use(express.static('public'));
app.use(bodyParser.json());

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

*/

var express = require('express');
var mysql = require('./sqlstart.js');

var app = express();
var handlebars = require('express-handlebars').create({defaultLayout:'main'});
app.use(express.static('public'));
app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');
app.set('port', 3118);

app.get('/reset-table',function(req,res,next){
    var context = {};
    mysql.pool.query("DROP TABLE IF EXISTS workouts", function(err){
        var createString = "CREATE TABLE workouts("+
            "id INT PRIMARY KEY AUTO_INCREMENT,"+
            "name VARCHAR(255) NOT NULL,"+
            "reps INT,"+
            "weight INT,"+
            "date DATE,"+
            "lbs BOOLEAN)";
        mysql.pool.query(createString, function(err){
            context.results = "Table reset";
            res.render('form',context);
        })
    });
});

app.get('/delete', function(req, res, next){
    var deleterow = {};
    mysql.pool.query("DELETE FROM workouts WHERE id=?", [req.query.id], function(err, result){
      if(err){
          next(err);
          return;
      }
    mysql.pool.query('SELECT * FROM workouts', function(err, rows, fields){
        if(err){
            next(err);
            return;
        }
        deleterow.results = rows;
        res.render('form',deleterow);
    });
    });
});

app.get('/edit', function(req, res, next){
    var editexercise = {};
    mysql.pool.query("SELECT * FROM workouts WHERE id=?", [req.query.ide], function(err, result){
        if(err){
            next(err);
            return;
        }
     if(result.length == 1){
         var curVals = result[0];
         mysql.pool.query("UPDATE workouts SET name=?, reps=?, weight=?, date=?, lbs=?", [req.query.name||curVals.name, req.query.reps||curVals.reps, req.query.weight||curVals.weight, req.query.date||curVals.date, req.query.lbs||curVals.lbs],function(err, result){
             if(err){
                 next(err);
                 return;
             }
             editexercise.results = results.changedRows;
             res.render(main, editexercise);
             })
     }

    });
});

app.get('/insert',function(req,res,next){
    var newexercise = {};
    mysql.pool.query("INSERT INTO workouts(`name`, reps, weight, date, lbs) VALUES (?, ?, ?, ?, ?)", [req.query.a, req.query.b, req.query.c, req.query.d, req.query.e], function(err, result){
        if(err){
            next(err);
            return;
        }
    mysql.pool.query('SELECT * FROM workouts', function(err, rows, fields){
        if(err){
            next(err);
            return;
        }
        newexercise.results = rows;
        res.render('form', newexercise);
    });
    });
});

app.get('/', function(req, res){
    res.render('form');
});

app.use(function(req,res){
    res.status(404);
    res.render('404');
});

app.use(function(err, req, res, next){
    console.error(err.stack);
    res.status(500);
    res.render('505');
});
module.exports = app;

app.listen(app.get('port'), function(){
    console.log('Express started on http://localhost:' + app.get('port') + '; press Ctrl-C to terminate.');
});
